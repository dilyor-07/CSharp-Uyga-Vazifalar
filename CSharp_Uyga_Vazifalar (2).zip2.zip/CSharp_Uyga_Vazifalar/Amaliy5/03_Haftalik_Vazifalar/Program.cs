using System;

class Program
{
    static void Main()
    {
        string[] kunlar = { "Dushanba", "Seshanba", "Chorshanba", "Payshanba", "Juma", "Shanba", "Yakshanba" };
        int[] vazifalar = new int[7];

        for (int i = 0; i < 7; i++)
        {
            Console.Write($"{kunlar[i]} kuni vazifalar soni: ");
            vazifalar[i] = int.Parse(Console.ReadLine() ?? "0");
        }

        int engBandKun = 0;
        for (int i = 1; i < 7; i++)
        {
            if (vazifalar[i] > vazifalar[engBandKun])
                engBandKun = i;
        }

        Console.WriteLine($"Eng ko'p vazifali kun: {kunlar[engBandKun]} ({vazifalar[engBandKun]} ta)");
    }
}
