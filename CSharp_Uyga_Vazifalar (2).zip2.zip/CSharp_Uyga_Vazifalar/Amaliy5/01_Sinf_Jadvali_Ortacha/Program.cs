using System;

class Program
{
    static void Main()
    {
        // Qatorlar - o'quvchilar, ustunlar - fanlar
        int[,] ballar =
        {
            { 80, 90, 70 },
            { 75, 85, 95 },
            { 90, 80, 85 },
            { 70, 75, 80 }
        };

        string[] fanlar = { "Matematika", "Informatika", "Ingliz tili" };

        for (int ustun = 0; ustun < ballar.GetLength(1); ustun++)
        {
            int yigindi = 0;
            for (int qator = 0; qator < ballar.GetLength(0); qator++)
                yigindi += ballar[qator, ustun];

            double ortacha = (double)yigindi / ballar.GetLength(0);
            Console.WriteLine($"{fanlar[ustun]} fanidan o'rtacha: {ortacha:F1}");
        }
    }
}
