using System;

class Program
{
    static void Main()
    {
        Console.Write("Hisob summasi: ");
        double summa = double.Parse(Console.ReadLine() ?? "0");

        Console.Write("Chegirma kodi: ");
        string kod = Console.ReadLine() ?? "";

        double chegirma = kod == "STUDENT10" ? summa * 0.10 : 0;
        double yakuniy = summa - chegirma;

        Console.WriteLine($"Chegirma: {chegirma:F2}");
        Console.WriteLine($"To'lanadigan summa: {yakuniy:F2}");
    }
}
