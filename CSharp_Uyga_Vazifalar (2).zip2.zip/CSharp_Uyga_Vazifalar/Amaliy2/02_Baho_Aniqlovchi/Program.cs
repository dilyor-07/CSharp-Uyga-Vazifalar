using System;

class Program
{
    static void Main()
    {
        Console.Write("100 ballik tizimdagi natijani kiriting: ");
        if (!int.TryParse(Console.ReadLine(), out int ball) || ball < 0 || ball > 100)
        {
            Console.WriteLine("Ball 0 dan 100 gacha bo'lishi kerak.");
            return;
        }

        int baho;
        if (ball >= 86) baho = 5;
        else if (ball >= 71) baho = 4;
        else if (ball >= 60) baho = 3;
        else baho = 2;

        Console.WriteLine($"5 ballik tizimdagi baho: {baho}");
    }
}
