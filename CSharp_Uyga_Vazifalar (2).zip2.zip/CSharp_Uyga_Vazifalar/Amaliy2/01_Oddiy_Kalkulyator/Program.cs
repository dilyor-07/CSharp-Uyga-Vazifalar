using System;

class Program
{
    static void Main()
    {
        Console.Write("Birinchi son: ");
        double a = double.Parse(Console.ReadLine() ?? "0");

        Console.Write("Ikkinchi son: ");
        double b = double.Parse(Console.ReadLine() ?? "0");

        Console.Write("Amalni kiriting (+, -, *, /): ");
        string amal = Console.ReadLine() ?? "";

        switch (amal)
        {
            case "+": Console.WriteLine($"Natija: {a + b}"); break;
            case "-": Console.WriteLine($"Natija: {a - b}"); break;
            case "*": Console.WriteLine($"Natija: {a * b}"); break;
            case "/":
                if (b == 0) Console.WriteLine("Nolga bo'lish mumkin emas.");
                else Console.WriteLine($"Natija: {a / b}");
                break;
            default: Console.WriteLine("Noto'g'ri amal kiritildi."); break;
        }
    }
}
