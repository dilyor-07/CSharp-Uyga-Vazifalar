using System;

class Program
{
    static int EngKatta(params int[] sonlar)
    {
        if (sonlar.Length == 0)
            throw new ArgumentException("Kamida bitta son kiriting.");

        int katta = sonlar[0];
        foreach (int son in sonlar)
        {
            if (son > katta)
                katta = son;
        }
        return katta;
    }

    static void Main()
    {
        Console.Write("Sonlarni probel bilan ajratib kiriting: ");
        string[] qismlar = (Console.ReadLine() ?? "").Split(' ', StringSplitOptions.RemoveEmptyEntries);

        int[] sonlar = Array.ConvertAll(qismlar, int.Parse);

        if (sonlar.Length == 0)
        {
            Console.WriteLine("Son kiritilmadi.");
            return;
        }

        Console.WriteLine($"Eng katta son: {EngKatta(sonlar)}");
    }
}
