using System;

class Program
{
    static long FaktorialRekursiv(int n)
    {
        if (n <= 1) return 1;
        return n * FaktorialRekursiv(n - 1);
    }

    static long FaktorialIterativ(int n)
    {
        long natija = 1;
        for (int i = 2; i <= n; i++)
            natija *= i;
        return natija;
    }

    static void Main()
    {
        Console.Write("0 dan 20 gacha butun son kiriting: ");
        if (!int.TryParse(Console.ReadLine(), out int n) || n < 0 || n > 20)
        {
            Console.WriteLine("Son 0 dan 20 gacha bo'lishi kerak.");
            return;
        }

        Console.WriteLine($"Rekursiv: {FaktorialRekursiv(n)}");
        Console.WriteLine($"Iterativ: {FaktorialIterativ(n)}");
    }
}
