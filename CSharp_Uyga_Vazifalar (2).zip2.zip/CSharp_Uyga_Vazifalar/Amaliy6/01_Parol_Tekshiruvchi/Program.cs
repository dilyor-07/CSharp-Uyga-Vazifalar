using System;

class Program
{
    static void Main()
    {
        Console.Write("Parol kiriting: ");
        string parol = Console.ReadLine() ?? "";

        bool kattaHarf = false;
        bool kichikHarf = false;
        bool raqam = false;
        bool maxsusBelgi = false;
        string maxsusBelgilar = "!@#$%";

        foreach (char belgi in parol)
        {
            if (char.IsUpper(belgi)) kattaHarf = true;
            if (char.IsLower(belgi)) kichikHarf = true;
            if (char.IsDigit(belgi)) raqam = true;
            if (maxsusBelgilar.Contains(belgi)) maxsusBelgi = true;
        }

        if (parol.Length >= 8 && kattaHarf && kichikHarf && raqam && maxsusBelgi)
            Console.WriteLine("Parol kuchli.");
        else
            Console.WriteLine("Parol talabga javob bermaydi. Kamida 8 belgi, katta-kichik harf, raqam va !@#$% dan belgi kerak.");
    }
}
