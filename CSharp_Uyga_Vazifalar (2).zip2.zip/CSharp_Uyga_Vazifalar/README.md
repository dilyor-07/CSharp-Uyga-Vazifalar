# 1–6-amaliy mashg‘ulotlar — uyga vazifalar

Ushbu repository C# Console dasturlari uchun tayyorlangan.

## Papkalar
- `Amaliy1` — ID karta, uy hayvoni profili, ijodiy profil.
- `Amaliy2` — kalkulyator, baho aniqlovchi, restoran chegirmasi.
- `Amaliy3` — son taxmin qilish, 3 ga bo‘linadigan sonlar, yulduzcha piramida.
- `Amaliy4` — harorat jurnali, juft sonlar, o‘rtachadan past ballar.
- `Amaliy5` — fanlar bo‘yicha o‘rtacha, 3x3 massiv yig‘indisi, haftalik vazifalar.
- `Amaliy6` — parol tekshiruvchi, faktorial, params orqali eng katta son.

## Ishga tushirish
Har bir topshiriq papkasida alohida `Program.cs` bor. Visual Studio yoki .NET Console loyiha ichiga kodni joylab ishga tushiring.

## Eslatma
Varaqalardagi ko‘rinib turgan uyga vazifalar asosida tayyorlandi. Ba’zi topshiriqlarda boshlang‘ich massiv qiymatlari namunaviy qilib berilgan; kerak bo‘lsa o‘qituvchi talabiga moslab o‘zgartiring.
