using System;

class Program
{
    static void Main()
    {
        Console.Write("Ismingiz: ");
        string ism = Console.ReadLine() ?? "";

        Console.Write("Yoshingiz: ");
        string yosh = Console.ReadLine() ?? "";

        Console.Write("Manzilingiz: ");
        string manzil = Console.ReadLine() ?? "";

        Console.Write("Sevimli rangingiz: ");
        string rang = Console.ReadLine() ?? "";

        Console.Write("Telefon raqamingiz: ");
        string telefon = Console.ReadLine() ?? "";

        Console.WriteLine("\n+----------------------------------+");
        Console.WriteLine("|              ID KARTA            |");
        Console.WriteLine("+----------------------------------+");
        Console.WriteLine($"| Ism:       {ism}");
        Console.WriteLine($"| Yosh:      {yosh}");
        Console.WriteLine($"| Manzil:    {manzil}");
        Console.WriteLine($"| Rang:      {rang}");
        Console.WriteLine($"| Telefon:   {telefon}");
        Console.WriteLine("+----------------------------------+");
    }
}
