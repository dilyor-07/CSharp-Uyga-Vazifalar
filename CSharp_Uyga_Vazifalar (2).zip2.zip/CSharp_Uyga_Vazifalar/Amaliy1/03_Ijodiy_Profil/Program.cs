using System;

class Program
{
    static void Main()
    {
        Console.Write("Ismingiz: ");
        string ism = Console.ReadLine() ?? "";

        Console.Write("Tug'ilgan yilingiz: ");
        int yil = int.Parse(Console.ReadLine() ?? "0");

        Console.Write("Bo'yingiz (sm): ");
        double boy = double.Parse(Console.ReadLine() ?? "0");

        Console.Write("Sevimli faningiz: ");
        string fan = Console.ReadLine() ?? "";

        Console.Write("Sport bilan shug'ullanasizmi? (ha/yo'q): ");
        string sport = Console.ReadLine() ?? "";

        Console.Write("Ismingizning bosh harfi: ");
        char harf = char.Parse(Console.ReadLine() ?? "A");

        Console.Write("Sevimli raqamingiz: ");
        int raqam = int.Parse(Console.ReadLine() ?? "0");

        Console.WriteLine("\n========== MENING PROFILIM ==========");
        Console.WriteLine($"Ism: {ism} ({harf})");
        Console.WriteLine($"Tug'ilgan yil: {yil}");
        Console.WriteLine($"Bo'y: {boy} sm");
        Console.WriteLine($"Sevimli fan: {fan}");
        Console.WriteLine($"Sport: {sport}");
        Console.WriteLine($"Sevimli raqam: {raqam}");
        Console.WriteLine("=====================================");
    }
}
