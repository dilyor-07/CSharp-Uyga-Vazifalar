using System;

class Program
{
    static void Main()
    {
        Console.Write("Hayvon nomi: ");
        string nomi = Console.ReadLine() ?? "";

        Console.Write("Hayvon turi: ");
        string turi = Console.ReadLine() ?? "";

        Console.Write("Yoshi: ");
        string yosh = Console.ReadLine() ?? "";

        Console.WriteLine("\n========== UY HAYVONI PROFILI ==========");
        Console.WriteLine($"Nomi: {nomi}");
        Console.WriteLine($"Turi: {turi}");
        Console.WriteLine($"Yoshi: {yosh}");
        Console.WriteLine("========================================");
    }
}
