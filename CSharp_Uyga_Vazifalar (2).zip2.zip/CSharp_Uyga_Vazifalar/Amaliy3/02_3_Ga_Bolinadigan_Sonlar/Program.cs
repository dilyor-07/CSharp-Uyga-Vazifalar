using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("1 dan 50 gacha 3 ga bo'linadigan sonlar:");
        for (int i = 1; i <= 50; i++)
        {
            if (i % 3 == 0)
                Console.Write(i + " ");
        }
        Console.WriteLine();
    }
}
