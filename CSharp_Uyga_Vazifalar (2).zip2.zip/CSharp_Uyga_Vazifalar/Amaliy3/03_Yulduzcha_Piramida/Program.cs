using System;

class Program
{
    static void Main()
    {
        for (int qator = 1; qator <= 4; qator++)
        {
            for (int yulduz = 1; yulduz <= qator; yulduz++)
                Console.Write("* ");
            Console.WriteLine();
        }
    }
}
