using System;

class Program
{
    static void Main()
    {
        Random random = new Random();
        int sirliSon = random.Next(1, 101);
        bool topildi = false;

        for (int urinish = 1; urinish <= 7; urinish++)
        {
            Console.Write($"{urinish}-urinish. 1 dan 100 gacha son kiriting: ");
            if (!int.TryParse(Console.ReadLine(), out int taxmin))
            {
                Console.WriteLine("Iltimos, butun son kiriting.");
                urinish--;
                continue;
            }

            if (taxmin == sirliSon)
            {
                Console.WriteLine("Tabriklaymiz, topdingiz!");
                topildi = true;
                break;
            }

            Console.WriteLine(taxmin < sirliSon ? "Kattaroq son kiriting." : "Kichikroq son kiriting.");
        }

        if (!topildi)
            Console.WriteLine($"7 ta urinish tugadi. Sirli son: {sirliSon}");
    }
}
