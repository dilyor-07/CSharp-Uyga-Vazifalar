using System;

class Program
{
    static void Main()
    {
        int[] sonlar = { 4, 7, 12, 9, 18, 21, 30, 5 };

        Console.WriteLine("Massivdagi juft sonlar:");
        foreach (int son in sonlar)
        {
            if (son % 2 == 0)
                Console.Write(son + " ");
        }
        Console.WriteLine();
    }
}
