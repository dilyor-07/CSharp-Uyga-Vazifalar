using System;

class Program
{
    static void Main()
    {
        int[] ballar = { 75, 90, 60, 85, 70 };

        double ortacha = 0;
        foreach (int ball in ballar)
            ortacha += ball;

        ortacha /= ballar.Length;

        int pastlarSoni = 0;
        foreach (int ball in ballar)
        {
            if (ball < ortacha)
                pastlarSoni++;
        }

        Console.WriteLine($"O'rtacha ball: {ortacha:F1}");
        Console.WriteLine($"O'rtachadan past ball olganlar: {pastlarSoni}");
    }
}
