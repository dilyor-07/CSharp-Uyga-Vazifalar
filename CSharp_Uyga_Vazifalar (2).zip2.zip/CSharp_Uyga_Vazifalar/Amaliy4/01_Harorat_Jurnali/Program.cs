using System;

class Program
{
    static void Main()
    {
        double[] harorat = new double[7];

        for (int i = 0; i < harorat.Length; i++)
        {
            Console.Write($"{i + 1}-kun harorati: ");
            harorat[i] = double.Parse(Console.ReadLine() ?? "0");
        }

        int engIssiq = 0, engSovuq = 0;
        for (int i = 1; i < harorat.Length; i++)
        {
            if (harorat[i] > harorat[engIssiq]) engIssiq = i;
            if (harorat[i] < harorat[engSovuq]) engSovuq = i;
        }

        Console.WriteLine($"Eng issiq kun: {engIssiq + 1}-kun, {harorat[engIssiq]}°");
        Console.WriteLine($"Eng sovuq kun: {engSovuq + 1}-kun, {harorat[engSovuq]}°");
    }
}
